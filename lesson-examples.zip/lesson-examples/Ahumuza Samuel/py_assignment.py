# Number 1
#Python program to solve a puzzle

base_number = 8
expotential_number = 2

power_result = base_number**expotential_number

print(power_result)

#Number 2
#I am working with a large number
large_number = 17

#Number 3
#Quatient division
quotient_division = large_number//base_number

print(quotient_division)

#Number 4
#Exact division
exact_division = large_number/base_number

print(exact_division)

#Number 5
#Final value 
final_value = power_result + quotient_division + exact_division
print(final_value)
print(type(final_value))
