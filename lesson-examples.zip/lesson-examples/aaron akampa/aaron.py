base = 9
exp = 4
my_exp=base**exp
my_third_number=89
quotient= my_third_number//base
exact_value= my_third_number/base
final_value=my_exp+quotient+exact_value
print(final_value)
print(type(final_value))

