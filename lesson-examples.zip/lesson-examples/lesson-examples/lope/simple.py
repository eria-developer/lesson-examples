name = "Haruna Libero"
about = "This is a simple brief about myself. And my weight is directly equal to my height"
#Just wanted to do some simple calculations so that I can practice the addition staff.
calculation_for_my_age = 2 + 3 + 5 +7 
favourite_sport, position_I_play, laptop_type = "volleyball", "libero ovk", "HP"
explanation = "Sice I was telling you as you can see my height is the same as my weight."
height = weight = "weight=34"


print(name)
print(about)
print(calculation_for_my_age)
print(favourite_sport)
print(position_I_play)
print(laptop_type)
print(weight)
print(height)