#Declarring the variables for the base and power
base = 7
exponent = 13

#Computing the result of raising the base to the power
exponent_result = base**exponent

#Choosing a third, larger number
third_number = 45

#Dividing the third number by the first
division_result = third_number/base
quotient = third_number//base

#Finding the final value
final_value = exponent_result + division_result + quotient

#Displaying the results
print(final_value)
print(type(final_value))