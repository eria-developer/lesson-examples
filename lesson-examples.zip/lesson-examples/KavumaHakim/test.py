first_number = 8
second_number = 2
third_number = 30

result_of_exponetion = first_number ** second_number
division_with_remainder = third_number / first_number
division_without_remainder = third_number // first_number

sum_of_all = result_of_exponetion + division_with_remainder + division_without_remainder

print(sum_of_all)
print(type(sum_of_all))
