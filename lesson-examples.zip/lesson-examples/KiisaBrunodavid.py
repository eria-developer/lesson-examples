base_number = 9
second_number = 4

exponential = base_number ** second_number


third_number = 100
quotient = third_number // base_number
exact_division = third_number / base_number

final = exponential + quotient + exact_division 
  
print (final)
print (type(final))





 