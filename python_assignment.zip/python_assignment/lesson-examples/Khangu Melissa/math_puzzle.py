#first number
base=2

#second number
exponent=3

#exponential calculation
exponential_value=base**exponent

#third number
third_value=24

#quotient with no remainder
quotient=third_value//base

#exact_division_value
exact_division_value=third_value/base

#total
total=exponential_value+quotient+exact_division_value

#output
print(total)
print(type(total))

