premiere_no=6
deuxieme_no=10
multiple= premiere_no**deuxieme_no
#print(multiple)
plus_grand_no=15
quotient= plus_grand_no/premiere_no
#print (plus_grand_no)
exact_quotient= plus_grand_no//premiere_no
#print(exact_quotient)
ajout_dautre= multiple + quotient + exact_quotient 
print(ajout_dautre)
print (type(ajout_dautre))

