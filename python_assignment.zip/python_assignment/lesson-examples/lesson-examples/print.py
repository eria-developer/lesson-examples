# my_name = "Jack"
# my_Name = "Harry Potter"
# myage = 45
# _another_variable_name = "Nigeria"

# print(my_Name)
# print(my_Name)
# print(my_Name)
# print(myage)
# print(_another_variable_name)

# my2age = 45
# print(my2age)

# # for, if, elif, else, print, def, class, 

# # my name = "Jack"
# my_football_club = "Nottingham"
# print(my_football_club)

# my_float_number = 34.89
# print(my_float_number)

# # print() as a function
# # type() as a function

# print(type(my_Name))
# print(type(my_float_number))

# my_variable_type = type(my2age)

# print(my_variable_type)
# print(type(my2age))


# my_variable = 5
# variable_my = 2 + 5 + 6

# type_of_variable_my = type(variable_my)

# print(variable_my)
# print(type_of_variable_my)


# my_variable = "Harry Potter"
# my_variable2 = 5

# my_variable3 = 3 + 2
# print(my_variable3)

# type_of_my_variable = type(my_variable)
# print(type_of_my_variable)

#Many variables can be assigned to multiple values at once
# first_name, last_name, middle_name = "Eria", "Jack", "Jibril"
# print(first_name)
# print(middle_name)

# One value can be assigned to many variables at once
first_name = last_name = middle_name = "Haruna"
# first_name = "Haruna"
# last_name = "Haruna"
# middle_name = "Haruna"
# print(first_name)
# print(last_name)
# print(middle_name)

#for if else elif def class

# print(first_name)


# my_name, my_age = my_weight =  19, "Allan"
# print(my_weight)

# print(my_age)

# my_name = 10
# my_age = 10
# my_weight = 10

# my_name = my_age = my_weight = 10


# my_name = "Benjamin"
# print("What is your name? My name is Kavuma I love food")
# print("What is your name?\n My name is Kavuma\n I love food")





# = is an assignment operator
# == is a comparison operator

# VARIABLE NAMES 
# snake_case
# camelCase    myName = "Qaima"    myAge = 46
# PascalCase    MyName = "Qaima"    MyAge = 45


print("I want to display this")
print(475)
print(546.23)

my_name = "Priscillah"


print(my_name)      # Priscillah
print("my_name")    #my_name


