# # my_name = "Harry Potter"

# # # print(my_name)
# # # print("my_name")
# # # print("bla bla bla bla")

# # my_age = 58

# # my_float_number = 45.123

# # print(my_age)
# # print(my_float_number)

# # print()     # This function displys output to the user

# # type()      # This function helps to display the type of a particular variable
# # in python, we have data types like int, str, list, float etc

# # my_name_type = type(my_name)


# # ###############


# my_name = "Harry"

# my_name_type = type(my_name)

# print(my_name_type)


# my_expression = 2 + 8 + 11
# print(my_expression)        # 2 + 8 + 11


# my_age = 74
# print(type(my_age))

# my_weight = 74.12
# print(type(my_weight))



# my_fav_artist = "Kafeero"
# my_fav_football = "United"
# print(my_fav_artist)

# # Print somethings about you, like the name, age, weight, favorite musician, etc

# # keywords that allow indentation of code, for, if, else, elif, class, def

# # Variable names must start with a letter or underscore
# _my_friend = "Diana"
# print(_my_friend)

# # 3my_friend = "Simon"
# # print(3my_friend)

# my_friend3 = "Claire"
# print(my_friend3)


# #variables are case sensitive
# my_other_friend = "Harry Potter"
# My_other_friend = "Vanessa"

# print(my_other_friend)
# print(My_other_friend)

# # Varibales should not be reserved keywords e.g for, if, elif, else, def, class, random, etcetc
# # elif = "Jack"
# # print(elif)

# # my friend = "Mugabe"          This is not allowed


# my_friend = "Diana"
# print(my_friend)


# my_friend = "Melissa"
# print(my_friend)


# my_current_friend = "Faith Nakibuule"
# my_previous_friend = "Melissa"
# my_first_friend = "Timothy"

#Assigning multiple values to variables
# my_current_friend, my_previous_friend, my_first_friend = "Faith Nakibuule", "Melissa", "Timothy"

# print(my_current_friend)
# print(my_previous_friend)
# print(my_first_friend)

# #Assigning a single value to multiple variables
# my_name = "Jack"
# my_brother_name = "Jack"
# my_sister_name = "Jack"

# # my_name = my_brother_name = my_sister_name = "Jack"

# print(my_name)
# print(my_sister_name)
# print(my_brother_name)


# # Numeric data types 
# # Integer Int 
# print(4)
# print(-4)
# print(type(4))
# print(type(-4))

# # Floats 
# print(type(-98.34))

# # String type 
# print(type("How are you"))

# my_string = "Hey there"
# print(type(my_string))

# #Boolean data type
# #It contains two values ie True and False
# print(type(True))
# print(type(False))


# #Coplex numbers
# my_complex_number = 1 + 2j
# print(type(my_complex_number))


# #Escape characters
# statement = 'Joshua\'s mother'
# print(statement)

# #Lists
# my_fav_colors = ["purple", "Army green", "Deep blue"]
# print(type(my_fav_colors))


# ARITHMETIC OPERATORS
# Addition
my_first_number = 15
my_second_number = 3

print(my_first_number + my_second_number)
print(my_first_number - my_second_number)
print(my_first_number * my_second_number)
print(my_first_number / my_second_number)
print(2**4)
print(3/4)
print(7/2)
print(7//2)
print(my_first_number // my_second_number)
print(7%2)

# print(pi)
# 2**3 = 2*2*2
# 4**5 = 4*4*4*4*4

#12 // 5 = It gives you how many times 5 can go into 12
print(12//5)