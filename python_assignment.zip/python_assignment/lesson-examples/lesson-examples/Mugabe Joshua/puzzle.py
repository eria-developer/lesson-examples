first = 8
second = 3

power_result = first ** second

new_num = 79

exact_div = new_num / first
quot = new_num // first

final_value = power_result + exact_div + quot
print(final_value)
print(type(final_value))